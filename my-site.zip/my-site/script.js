// Script to simulate search
document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.querySelector('input');

    searchInput.addEventListener('keypress', function(event) {
        if (event.key === 'Enter') {
            alert(`Searching for restaurants related to: "${searchInput.value}"`);
        }
    });
});
